package com.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.entity.Select;


public interface selectMapper extends BaseMapper<Select> {

}
